import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time


USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
base='http://norad.wtf/'
ADDON=xbmcaddon.Addon(id='plugin.video.oculus')
    
    
VERSION = "0.0.5"
PATH = "OCULUS"            

#########################################################################################################################################################
#__language__ = addon.getLocalizedString
skinspath  =  xbmc.translatePath(os.path.join('special://home','addons','plugin.video.oculus','resources','skins'))
oculuspath  =  xbmc.translatePath(os.path.join('special://home','addons','plugin.video.oculus'))
dialog = xbmcgui.Dialog()

fanart_background = xbmc.translatePath(os.path.join(oculuspath,'fanart.jpg'))
install_icon = xbmc.translatePath(os.path.join(skinspath,'install.png'))
info_icon = xbmc.translatePath(os.path.join(skinspath,'info.png'))
comingsoon_icon = xbmc.translatePath(os.path.join(skinspath,'comingsoon.png'))
#########################################################################################################################################################
   
def CATEGORIES():
    addDir('ISENGARD BUILD','http://norad.wtf/4yoursake/oculus-isengard.zip',1,install_icon,fanart_background,'Install Isengard Build.')
    addDir('JARVIS BUILD','http://norad.wtf/4yoursake/',2,comingsoon_icon,fanart_background,'Coming soon... Jarvis build!')
    addDir('INFORMATION','http://norad.wtf/4yoursake/',3,info_icon,fanart_background,'Information')
    setView('movies', 'MAIN')
    
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
def wizard(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("[COLOR red]OCULUS[/COLOR]","[COLOR red]Downloading... [/COLOR]",'', '[COLOR red]Please wait...[/COLOR]')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "[COLOR red]Installing...[/COLOR]")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog.ok("[COLOR red]Attention[/COLOR]", "[COLOR yellow]Installation is nearly complete however a critical step remains! [/COLOR]")
    dialog.ok("[COLOR red]Attention[/COLOR]", "[COLOR yellow]You must immediately power cycle for the setup to be properly completed. [/COLOR]", "[COLOR white][CR]Any other action will cause problems with your installation. [/COLOR]")

def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
 
def ComingSoon():
    dialog.ok('[COLOR red]Coming soon[/COLOR]','','[COLOR white]Get ready... [/COLOR][COLOR white]another[/COLOR] [COLOR red]OCULUS[/COLOR][COLOR white] build is coming soon![/COLOR]','[COLOR white][/COLOR]')

def Information():
    dialog.ok('[COLOR red]For More Information[/COLOR]','[COLOR white]Follow me on [COLOR skyblue]Twitter[/COLOR] [COLOR yellow]@4yoursak[/COLOR] [COLOR white]and[/COLOR] [COLOR yellow]@ladon_media[/COLOR]','','[COLOR white]Visit my website: [/COLOR][COLOR orange]www.ladonmedia.com[/COLOR]')

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        CATEGORIES()
       
elif mode==1:
        wizard(name,url,description)

elif mode==2:
        ComingSoon()

elif mode==3:
        Information()

        
xbmcplugin.endOfDirectory(int(sys.argv[1]))

