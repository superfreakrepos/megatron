import xbmc,xbmcaddon,os,re


PLUGIN='skin.star.wars'
ADDON = xbmcaddon.Addon(id=PLUGIN)


def setSetting(setting, value):
    setting = '"%s"' % setting

    if isinstance(value, list):
        text = ''
        for item in value:
            text += '"%s",' % str(item)

        text  = text[:-1]
        text  = '[%s]' % text
        value = text

    elif not isinstance(value, int):
        value = '"%s"' % value

    query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (setting, value)
    xbmc.executeJSONRPC(query)

def getSetting(setting):
  
        import json
        setting = '"%s"' % setting
 
        query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (setting)
        response = xbmc.executeJSONRPC(query)

        response = json.loads(response)                

        if response.has_key('result'):
            if response['result'].has_key('value'):
                return response ['result']['value'] 


setting = 'lookandfeel.skin'
skin = getSetting(setting)

if skin=='skin.star.wars':
    if ADDON.getSetting('firstrun')=='false':
        setSetting('lookandfeel.soundskin', 'resource.uisounds.star.wars')
        boolstxt =  xbmc.translatePath(os.path.join('special://home','addons','skin.star.wars','skinextras','bools.txt'))
        readbools = open(boolstxt).read()
        bools=re.compile('bool="(.+?)"').findall(readbools)
        for boolname in bools: xbmc.executebuiltin('Skin.SetBool(%s)'%boolname)
        stringstxt =  xbmc.translatePath(os.path.join('special://home','addons','skin.star.wars','skinextras','strings.txt'))
        readstrings = open(stringstxt).read()
        strings=re.compile('string="(.+?)"').findall(readstrings)
        for stringname in strings: xbmc.executebuiltin('Skin.SetString(%s)'%stringname)
        ADDON.setSetting('firstrun','true')
        import time
        profile = xbmc.getInfoLabel("System.ProfileName" )
        time.sleep(5)
        xbmc.executebuiltin("LoadProfile(%s)"%profile)

